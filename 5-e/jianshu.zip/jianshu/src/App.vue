<script setup>
</script>

<template>
  <div>
    <RouterView />
  </div>
</template>

<style scoped>
</style>
